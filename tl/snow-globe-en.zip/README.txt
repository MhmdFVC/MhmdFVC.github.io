Install by placing these files into your game folder. If you are using the DLsite version or similar, the folder you want to copy the patch files into is StartData\GameData\data.

Also, due to technical limitations you will not have a great selection of fonts in-game. Thus, you should install one or both of the recommended fonts in the "RECOMMENDED FONTS" folder to select in-game.

(Note: If your language for non-Unicode programs is set to Japanese, the recommended fonts will be listed in-game in Japanese as モトヤLマルべり3等幅 and/or モトヤLシーダ3等幅)
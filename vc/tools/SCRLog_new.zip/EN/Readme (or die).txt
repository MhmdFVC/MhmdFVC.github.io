  __  __ _      __  __           _     
 |  \/  (_)    |  \/  |         | | 2023
 | \  / |___  _| \  / | ___   __| |___ 
 | |\/| | \ \/ / |\/| |/ _ \ / _` / __|
 | |  | | |>  <| |  | | (_) | (_| \__ \
 |_|  |_|_/_/\_\_|  |_|\___/ \__,_|___/
                                       

=======   MixMods.com.br   ======= - Best visualization with monospaced fonts, like "Consolas".


------- Instructions:

Extract the folder "SCRLog" to your Modloader folder.
*DO NOT* INSTALL THE MOD OUTSIDE MODLOADER FOLDER! IT MAY NOT WORK.
You can type "SCRL" during the game as a cheat to enable/disable processing, it will be saved in .ini (EXE 1.0 only). But mod will not be 100% disabled.

-- Download the latest version of Modloader: MixMods.com.br/2015/01/SA-Modloader.html


= How to use:
Tutorial: http://www.mixmods.com.br/2020/09/scrlog.html
This mod may take some FPS, but for a good propose. You may want to disable it for casual gameplays with an already very tested game.

 = Testing:
To test whether the mod is really working, install the CLEO mod from the "(test)" folder.
Your game will crash, and both in the crash window and at the end of "scrlog.log", the last script is called "testcra":
https://1.bp.blogspot.com/-OUWgHVuTWtM/X1aSUfBNY8I/AAAAAAAAZ38/0hPPGKpDVgEB351-3umS6v2sVGLPPzAgACLcBGAsYHQ/w1600-h1600/gta-mod-scrlog-crash-script-log.png
This means that the crash was caused by "testcrash.cs". You can now delete this test script from your game.
Remembering that the name of the script may not be the same as the file. If you can't find it, open "cleo.log" and search (CTRL+F), it will be on the top line.
If the window and "scrlog.log" have not been generated, check the installation or test other settings. Also, read bellow:

 = Settings:
By default comes with "3" setting, where all information is shown in the "scrlog.log" file at the time of the crash.
Only works inside the modloader folder.
If the crash window didn't work and you have GInput installed, try to change the GInput folder name to something else, like "GInput SA" or "zGInput".
Within the "(settings)" folder there are other options to choose from, in case it didn't work. Just replace the scrlog.ini with the chosen one.


Version: 2020.3 (CLEO+ v1.2 commands)
--------------------

Author: LINK/2012
Improvements: Junior_Djjr
GTA:VC JP support: lazyuselessman


====   MixMods.com.br                ====
====   fb.com/FamiliaMixMods         ====
====   youtube.com/JuniorDjjrMixMods ====


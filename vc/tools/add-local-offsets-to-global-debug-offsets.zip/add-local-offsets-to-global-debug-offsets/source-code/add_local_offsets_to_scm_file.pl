#!/usr/bin/perl
#failed perl2exe_include "strict.pm";
#use strict;
#use warnings;
#

if( !defined($ARGV[0]) or $ARGV[0] eq "-h" or $ARGV[0] eq "--help" ){
    my_die("drag and drop a file onto this script
more technical:
usage: /path/to/this/script.pl /path/to/main_scm_file.txt
");
}
print "hi\n";
my $in_file_path = $ARGV[0];
if( ! -f $in_file_path ){
    my_die("file with name \"$in_file_path\" does not exist\n");
}
if( ! -r $in_file_path ){
    my_die("file with name \"$in_file_path\" does exist but is not readable\n");
}
open( my $in_file, "<$in_file_path" );

print "outputting to \"out.txt\"\n";

open(my $out_file, ">out.txt") or my_die("Can't open output file with name \"out.txt\"\n");
my @lines = ();
while (<$in_file>){
    s/\r?\n//;
    s/\n//;
    chomp;
    push @lines, $_;
}
my $line;
my $i;


for( $i = 0; $lines[$i] !~ /^\/\/-+Mission/; $i++){
    print $out_file "$lines[$i]\n";
}

my $mission_start_offset;
my ($global_offset, $relative_offset, $rest_of_the_line);
my $j;
for( ; $i < @lines and $lines[$i] !~ /^\/\/-+External script/; ++$i ){
    $line = ( $lines[$i] =~ s/\r//r );
    if ( $line =~ m{Originally:} ) {
        print $out_file "$line\n";
        for( $j = $i; $lines[$j] !~ /^{\d+/; ++$j ){
        }
        ($mission_start_offset) = ($lines[$j] =~ /^{(\d+)}/);
        next;
    }

    if ( $line =~ /^\{\d+/ ) {
        ($global_offset, $rest_of_the_line) = ( $line =~ /^{(\d+)} (.*)/ );
        $relative_offset = $global_offset - $mission_start_offset;
        print $out_file sprintf "{%d % 5d} %s\n", $global_offset, $relative_offset, $rest_of_the_line;
    }else{
        print $out_file "$line\n";
    }
}

for( ; $i < @lines; ++$i ){
    print $out_file "$lines[$i]\n";
}
close $out_file;
close $in_file;




my $template = <<'END';
original="%s"
echo "checking for differences except for the intended added local offsets"
perl -pe 's/\s+\d+\}/}/' out.txt | tr -d "\r" >| cmp_new.txt
tr -d "\r" < "$original" >| cmp_old.txt

diff cmp_old.txt cmp_new.txt >| diff.txt
if (( 0 < "$( wc -l < diff.txt )" ));then
    echo "differences exist, view in diff.txt"
    echo "opening in vim text editor"
    vim diff.txt
else
    echo "no differences exist"
    rm diff.txt
fi
echo "cleanup"
rm cmp_old.txt cmp_new.txt
END
my $commands = sprintf $template, $in_file_path;
print "done\n\n\n\n";
print "to check for differences added by the script except for the ones intended (local offsets added) use these commands:\n";
print $commands;


print "\n\n\n\n";
print "Press ENTER to exit";
<STDIN>;

sub my_die {
	my $message = shift;
	print STDERR "$message";
	print "Press ENTER to exit";
	<STDIN>;
	exit 1;
}

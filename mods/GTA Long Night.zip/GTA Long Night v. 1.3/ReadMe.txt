_____________________________________________________________________________________

  G r a n d  T h e f t  A u t o : L o n g  N i g h t
_____________________________________________________________________________________


  ReadMe.txt


  Thank you for downloading Grand Theft Auto: Long Night.


_____________________________________________________________________________________

INSTALLATION INSTRUCTIONS:
Download GTA Mod installer from here  www.GTACOMPLEX.com if you don't already have it. Back up everything first. If you don't back up, there's nobody to blame but yourself.
Extract the zip file and then:

1. Run the Gta Mod Installer and click the option that says "Install  a mod (with a script file) to GTA3 or Vice City." It should be the bottom choice. Next choose to install from a folder, again the bottom choice. Then choose the folder holding the files(GTA LONG NIGHT) and tell it to run the INSTALLSCRIPT_GTAVC.TXT. 

2. When this is done, open the folder named "STEP 2", and add the contents to your GTA Vice City root directory (wherever GTA-VC.exe is located). After you do all this, the mod should be installed. 

Just run the GTA-LN.exe, and enjoy.

Save often. We highly recommended saving after every mission you complete - just to be safe.

The Fighting Hellfish have spent the past year developing a perilous epic.

We present to you an untapped innovaton of the modding community - 

A plot.

Yes, there is actual story progression. Everything else, while expansive in scope, just contributes to a whole larger than its parts.

You will not recognize Vice City.

Words can't do it justice. [I'm really pretty inarticulate, truth be told.] Go experience it now.

WARNING: Violent content and mature themes makes this game inappropriate for anyone under 17
Survival, insanity and undead ghoul hordes aren't for you.

You are not allowed to use any of our work. Contact at HellfishProductions@gmail.com 
Donations accepted.
Look for the walkthrough at:

Sawed-off shotgun model by Fernando Bresciano.


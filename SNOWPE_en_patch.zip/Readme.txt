Hi! Thank you for downloading the translation patch for Snow Plus Edition. We're the folks from Snowy Ryujin TL, and we want to give you some useful info about the game & patch before you read.
FONTS, GLOSSARY FEATURE & COLORED DIALOGUE: Upon starting a new game for the first time, the game will likely ask you what font to use. Avoid choosing Arial and Segoe UI, as they've been known to mess up our custom-made glossary entries a bit. Pick something safer like the classic Times New Roman. Included in this translation patch is a custom-made glossary feature, where you can select certain terms that show up throughout, and get a bit more information on them if you're curious. However, it's recommended to make sure you have colored dialogue turned on in the game options (found by right-clicking) otherwise all the text in the game will be white, and you won't know when a glossary term shows up!

H-SCENES: The 18+ content in Snow Plus Edition is completely optional. There's a feature in the game options to disable H-scenes altogether, where the game will encounter an H-scene and act of its own accord as if you chose the option that avoids it. However, if you have H-scenes enabled, there is ALWAYS a choice that will let you proceed to the H-scene or avoid it. The 18+ content in Snow Plus Edition is never forced on you. There is a small part in the Plus Edition route that leads to an H-scene but rest assured, the choice to avoid it will show up before things get too explicit. 

ENFORCED PLAYING ORDER: Snow is a fairly linearly structured VN. When starting it for the first time, you will be able to pursue the Sumino route, or the Asahi route. After that, you can pretty much only unlock the next routes in sequence. A guide is included with this patch as well, if you wish to use it. The Legend route is unlocked after completing Sumino route, but you cannot proceed to Shigure route until Legend and Asahi are both completed. You cannot proceed to Ouka route until Shigure is completed, you cannot proceed to Meiko route until Ouka is completed, and you cannot proceed to the Plus Edition version of Ouka route until Ouka is completed. 

STARTUP CRASH: Occasionally, when you launch the game, you might encounter a blank textbox and Snow will proceed to crash on you. Don't sweat it, that's just an occasional bug that ironically enough is the solution to a DIFFERENT bug that would cause Snow to crash every single time you started it. An occasional crash to save you from a neverending crash. Irony is beautiful.

GAME EDITION: If you have a different version of Snow (Original release, Full Voice Edition, Standard Edition or a port/ISO of the console/handheld editions) this patch WILL NOT WORK. This patch is made exclusively for Snow Plus Edition for the PC. If you downloaded the version of the patch that comes included with the game, you've got Plus Edition, you're all set. 

And that about does it! Thanks so much for your interest and support. We hope you enjoy reading Snow as much as we did bringing it to you. Happy trails!

CREDITS:
Mhmd - Translator
Tsukishiro - Translator
Takafumi - Translation Help & Image Editor
Waffletown - Proofreader & Text Editor
ChiayaChii - Tester
Rinny - Text Editor & Project Lead